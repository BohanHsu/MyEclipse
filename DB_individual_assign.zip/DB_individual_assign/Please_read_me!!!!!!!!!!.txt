Hello!
This folder including my solution of the assignment4.
I'm working on myEclipse to solve this problem and this fold is the root of my project.

The solution of problem 1 is in class "assign.problem1.ProblemSolution"
The solution of problem 2 is in a text file called "create_index_sql.txt", in the root folder.
The solution of problem 3 is in the package assign.entity
The solution of problem 4 is in class "assign.problem4.ProblemSolution"