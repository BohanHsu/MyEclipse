package assign.entity;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "RoleType")
public class RoleType {

	@Id
	@Column(name = "id")
	private Integer id;

	@Column(name = "type")
	private String type;

	@ManyToMany
	@JoinTable(name = "role", joinColumns = @JoinColumn(name = "hasRole"), inverseJoinColumns = {
			@JoinColumn(name = "isMemberOf"), @JoinColumn(name = "hasMenber") })
	private Set<Membership> memberships;

	
	public RoleType() {
		// TODO Auto-generated constructor stub
	}


	public RoleType(Integer id, String type, Set<Membership> memberships) {
		super();
		this.id = id;
		this.type = type;
		this.memberships = memberships;
	}


	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	public String getType() {
		return type;
	}


	public void setType(String type) {
		this.type = type;
	}


	public Set<Membership> getMemberships() {
		return memberships;
	}


	public void setMemberships(Set<Membership> memberships) {
		this.memberships = memberships;
	}
	
	
}
