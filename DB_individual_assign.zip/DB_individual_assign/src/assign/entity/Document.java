package assign.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Document")
public class Document {

	@Id
	@Column(name = "id")
	private Integer id;
	
	@Column(name = "title")
	private String title;
	
	@ManyToOne
	@JoinColumn(name = "id")
	private Team createdBy;
	
	@Column(name = "createdOn")
	private Date createdOn;
	
	@Column(name = "content")
	private String context;
	
	public Document() {
		// TODO Auto-generated constructor stub
	}

	public Document(Integer id, String title, Team createdBy, Date createdOn,
			String context) {
		super();
		this.id = id;
		this.title = title;
		this.createdBy = createdBy;
		this.createdOn = createdOn;
		this.context = context;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Team getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Team createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public String getContext() {
		return context;
	}

	public void setContext(String context) {
		this.context = context;
	}
	
	
}
