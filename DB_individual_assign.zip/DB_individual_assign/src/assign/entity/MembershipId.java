package assign.entity;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * MembershipId entity. @author MyEclipse Persistence Tools
 */
@Embeddable
public class MembershipId implements java.io.Serializable {

	// Fields

	private Integer hasMember;
	private Integer isMemberOf;

	// Constructors

	/** default constructor */
	public MembershipId() {
	}

	/** full constructor */
	public MembershipId(Integer hasMember, Integer isMemberOf) {
		this.hasMember = hasMember;
		this.isMemberOf = isMemberOf;
	}

	// Property accessors

	@Column(name = "hasMember", nullable = false)
	public Integer getHasMember() {
		return this.hasMember;
	}

	public void setHasMember(Integer hasMember) {
		this.hasMember = hasMember;
	}

	@Column(name = "isMemberOf", nullable = false)
	public Integer getIsMemberOf() {
		return this.isMemberOf;
	}

	public void setIsMemberOf(Integer isMemberOf) {
		this.isMemberOf = isMemberOf;
	}

	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof MembershipId))
			return false;
		MembershipId castOther = (MembershipId) other;

		return ((this.getHasMember() == castOther.getHasMember()) || (this
				.getHasMember() != null && castOther.getHasMember() != null && this
				.getHasMember().equals(castOther.getHasMember())))
				&& ((this.getIsMemberOf() == castOther.getIsMemberOf()) || (this
						.getIsMemberOf() != null
						&& castOther.getIsMemberOf() != null && this
						.getIsMemberOf().equals(castOther.getIsMemberOf())));
	}

	public int hashCode() {
		int result = 17;

		result = 37 * result
				+ (getHasMember() == null ? 0 : this.getHasMember().hashCode());
		result = 37
				* result
				+ (getIsMemberOf() == null ? 0 : this.getIsMemberOf()
						.hashCode());
		return result;
	}

}