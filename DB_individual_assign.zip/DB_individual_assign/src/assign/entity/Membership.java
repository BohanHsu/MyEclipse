package assign.entity;

import java.util.Date;
import java.util.Set;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.EmbeddedId;

//@IdClass(value = assign.entity.MembershipId.class)
@Entity
@Table(name = "Membership")
public class Membership {

	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "hasMember", column = @Column(name = "hasMember", nullable = false)),
			@AttributeOverride(name = "isMemberOf", column = @Column(name = "isMemberOf", nullable = false)) })
	private MembershipId id;

	@Column(name = "isMemberOf")
	private Integer isMemberOf;

	@Column(name = "hasMember")
	private Integer hasMenber;

//	@Column(name = "hasRole")
//	private Integer hasRole;

	@Column(name = "start")
	private Date start;

	@Column(name = "end")
	private Date end;

	@ManyToOne
	@JoinColumn(name = "hasMember")
	private Person person;

	@ManyToOne
	@JoinColumn(name = "isMemberOf")
	private Team team;

	@ManyToMany
	@JoinTable(name = "role", joinColumns = { @JoinColumn(name = "isMemberOf"),
			@JoinColumn(name = "hasMember")}, 
			inverseJoinColumns = @JoinColumn(name = "hasRole"))
	private Set<RoleType> roletypes;

	public Membership() {
		// TODO Auto-generated constructor stub
	}

	public Membership(MembershipId id, Integer isMemberOf, Integer hasMenber,
			Integer hasRole, Date start, Date end, Person person, Team team,
			Set<RoleType> roletypes) {
		super();
		this.id = id;
		this.isMemberOf = isMemberOf;
		this.hasMenber = hasMenber;
//		this.hasRole = hasRole;
		this.start = start;
		this.end = end;
		this.person = person;
		this.team = team;
		this.roletypes = roletypes;
	}

	public MembershipId getId() {
		return id;
	}

	public void setId(MembershipId id) {
		this.id = id;
	}

	public Integer getIsMemberOf() {
		return isMemberOf;
	}

	public void setIsMemberOf(Integer isMemberOf) {
		this.isMemberOf = isMemberOf;
	}

	public Integer getHasMenber() {
		return hasMenber;
	}

	public void setHasMenber(Integer hasMenber) {
		this.hasMenber = hasMenber;
	}

//	public Integer getHasRole() {
//		return hasRole;
//	}
//
//	public void setHasRole(Integer hasRole) {
//		this.hasRole = hasRole;
//	}

	public Date getStart() {
		return start;
	}

	public void setStart(Date start) {
		this.start = start;
	}

	public Date getEnd() {
		return end;
	}

	public void setEnd(Date end) {
		this.end = end;
	}

	public Person getPerson() {
		return person;
	}

	public void setPerson(Person person) {
		this.person = person;
	}

	public Team getTeam() {
		return team;
	}

	public void setTeam(Team team) {
		this.team = team;
	}

	public Set<RoleType> getRoletypes() {
		return roletypes;
	}

	public void setRoletypes(Set<RoleType> roletypes) {
		this.roletypes = roletypes;
	}

}
