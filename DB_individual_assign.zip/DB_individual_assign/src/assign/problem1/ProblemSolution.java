package assign.problem1;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProblemSolution {
	public void printDocumentInfo(Connection connection, String firstPartOfTitle) {

		ResultSet rs = findDocumentsByTitleFirstPart(connection,
				firstPartOfTitle);

		if (rs == null) {
			System.out.println("rs is null");
			return;
		}

		try {
			while (rs.next()) {
				int docId = rs.getInt(1);
				String title = rs.getString(2);
				int teamId = rs.getInt(3);
				Date dt = rs.getDate(4);

				System.out.println("=========================");
				System.out.println("title: " + title);
				System.out.println("team: "
						+ findTeamNameById(connection, teamId));
				System.out.println("data: " + dt);
				System.out.println("==Chairman==");
				List<String> listChair = findPeopleNameByTeamAndRole(
						connection, teamId, docId, "Chair");
				for (String string : listChair) {
					System.out.println("Chairman: " + string);
				}
				System.out.println("==Secretary==");
				List<String> listSecre = findPeopleNameByTeamAndRole(
						connection, teamId, docId, "Secretary");
				for (String string : listSecre) {
					System.out.println("Secertary: " + string);
				}
				System.out.println("");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	@SuppressWarnings("finally")
	private ResultSet findDocumentsByTitleFirstPart(Connection connection,
			String firstPartOfTitle) {

		ResultSet rs = null;
		PreparedStatement pstat = null;
		String sql = "select * " + "from document as d "
				+ "where d.title like ?;";
		firstPartOfTitle = firstPartOfTitle + "%";
		try {
			pstat = connection.prepareStatement(sql);
			pstat.setString(1, firstPartOfTitle);

			rs = pstat.executeQuery();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {

			if (pstat != null) {
				try {
					pstat.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return rs;
		}
	}

	@SuppressWarnings("finally")
	private String findTeamNameById(Connection conn, int id) {
		String name = null;

		String sql = "select name " + "from Team " + "where id = ?";
		PreparedStatement pstat = null;
		ResultSet rs = null;
		try {
			pstat = conn.prepareStatement(sql);
			pstat.setInt(1, id);

			rs = pstat.executeQuery();

			if (rs.next()) {
				name = rs.getString(1);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (pstat != null) {
				try {
					pstat.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return name;
		}
	}

	private List<String> findPeopleNameByTeamAndRole(Connection conn,
			int teamId, int docId, String roletype) {

		ArrayList<String> listOfName = new ArrayList<String>();
		String sql = "select p.name "
				+ "from team as t, membership as m, person as p, role as r, roletype as rt, document as d "
				+ "where t.id = m.isMemberOf " + "and p.id = m.hasMember "
				+ "and t.id = ? " + "and r.hasMember = m.hasMember "
				+ "and r.isMemberOf = m.isMemberOf " + "and r.hasRole = rt.id "
				+ "and d.id = ? " + "and rt.type = ? "
				+ "and datediff(d.createdOn, m.end) <= 0 "
				+ "and datediff(d.createdOn, m.start) >= 0; ";
		PreparedStatement pstat = null;
		ResultSet rs = null;

		try {
			pstat = conn.prepareStatement(sql);
			pstat.setInt(1, teamId);
			pstat.setInt(2, docId);
			pstat.setString(3, roletype);

			rs = pstat.executeQuery();

			while (rs.next()) {
				listOfName.add(rs.getString(1));
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (pstat != null) {
				try {
					pstat.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return listOfName;
		}
	}
}
