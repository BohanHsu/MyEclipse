package assign.problem4;

import java.sql.Connection;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import assign.entity.Document;
import assign.entity.Membership;
import assign.entity.Person;
import assign.entity.RoleType;

public class ProblemSolution {
	public void printDocumentInfo(EntityManager manager, String title) {
		
		String jsql1 = "select d from Document d where d.title = ?1";
		Query query = manager.createQuery(jsql1);
		query.setParameter(1, title);
		List rl = query.getResultList();
		
		for (Object object : rl) {
			Document doc = (Document) object;
			
			System.out.println("===========================================");
			System.out.println(doc.getTitle());
			System.out.println(doc.getCreatedBy().getName());
			
			Integer teamId = doc.getCreatedBy().getId();
			Date docDate = doc.getCreatedOn();
			
			System.out.println("Chairman");
			printRoleOfPersonInTimeInTeam(manager,"Chair", teamId,docDate);
			System.out.println("Secertary");
			printRoleOfPersonInTimeInTeam(manager,"Secretary", teamId,docDate);
			
		}
	}
	
	private void printRoleOfPersonInTimeInTeam(EntityManager manager, String role, Integer teamId, Date publishedDate){
		
		String jsql1 = "select m from Membership m where m.isMemberOf = ?1";
		Query query1 = manager.createQuery(jsql1);
		query1.setParameter(1, teamId);
		
		List rl1 = query1.getResultList();
		for (Object object : rl1) {
			Membership m = (Membership) object;
			if(compareDate(m, publishedDate)){
				Set<RoleType> rs = m.getRoletypes();
				for (RoleType roleType : rs) {
					if(roleType.getType().equals(role)){
						printPersonInfo(manager,m.getHasMenber());
					}
				}
			}
		}
	}
	

	
	private boolean compareDate(Membership m, Date d){
		if(m.getEnd() == null){
			return (d.compareTo(m.getStart()) > 0);
		}else{
			return (d.compareTo(m.getStart()) > 0) & (d.compareTo(m.getEnd()) < 0);
			
		}

	}
	
	private void printPersonInfo(EntityManager manager, Integer pid){
		Person p = manager.find(Person.class, pid);
		System.out.println(p.getName());
	}
	
	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("DB_individual_assign");
		EntityManager em = emf.createEntityManager();
		ProblemSolution ps4 = new ProblemSolution();
		ps4.printRoleOfPersonInTimeInTeam(em, "chair", 1, new Date(112,0,0));
	}
}
