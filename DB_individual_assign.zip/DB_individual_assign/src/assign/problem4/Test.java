package assign.problem4;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import assign.entity.Document;
import assign.entity.Person;

public class Test {
	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("DB_individual_assign");
		EntityManager em = emf.createEntityManager();
		
		ProblemSolution ps4 = new ProblemSolution();
		ps4.printDocumentInfo(em, "document1");
		
	}
}
