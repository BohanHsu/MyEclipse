package assign.problem4;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class Leaning {
	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence
				.createEntityManagerFactory("DB_individual_assign");
		EntityManager em = emf.createEntityManager();
		
		String sql1 = "select m from Membership m";
		
		Query query = em.createQuery(sql1);
//		query.setParameter(1, "document1");
		
		List rl = query.getResultList();
		
		for (Object object : rl) {
			System.out.println(object);
		}
	}
}
